function [phiT] = bspline(period, nOrders)
% obtain the sample of bspline of order N 
% Input:
% period: sampling period
% nOrders: the order of bspline
% Output:
% phiT: sample of bspline of a given order

boxFun = ones(1, period); % b-spline of order 0 is the box function
prevPhiT = boxFun; 
if nOrders == 0
    phiT = boxFun;
else
    for iOrder = 1: nOrders
        if mod(iOrder, 2)
            phiT = [0 conv(boxFun, prevPhiT)] / period; % the peak in the certer
        else
            phiT = [conv(boxFun, prevPhiT) 0] / period; % pad        
        end
        prevPhiT = phiT;
    end
end
end
